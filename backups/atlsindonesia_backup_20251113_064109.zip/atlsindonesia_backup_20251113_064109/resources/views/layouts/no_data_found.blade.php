<div class="ol-body-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="ol-card mb-3">
                    <div class="ol-card-body p-4">
                        <div class="card-centered-section">
                            <div class="card-middle-banner">
                                <img src="{{asset('assets/backend/images/no-file-search.svg')}}" alt="">
                            </div>
                            <p class="title2 fs-20px text-center"> {{get_phrase('No data found')}} </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>